<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LogIn</title>
</head>
<body>
    <form action="loginaction.php" method="post">
        Email: <input type="email" name="email">
        Phone: <input type="number" name="phone">
        <hr>
        <button>
            Log In
        </button>
        <br>
        <hr>
        <a href="form.php">
            New Registration
        </a>
        <hr>
    </form>
</body>
</html>