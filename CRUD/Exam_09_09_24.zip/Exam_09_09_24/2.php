<form action="qno_2_upload.php" method="POST" enctype="multipart/form-data">
    <input type="file" name="image" accept="image/*">
    <button type="submit" name="submit">upload</button>
    
</form>
