<?php

$severname="localhost";
$username="root";
$password="";
$db="test";
$conn=new mysqli($severname,$username,$password,$db);

?>
